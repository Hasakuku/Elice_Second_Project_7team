const { body, query } = require('express-validator');

exports.aa = [];