const cocktail = require('./cocktail');

module.exports = { cocktail };